USE Assignments 



 -- Create Employees1 table
 CREATE TABLE Employees1 (
   EmpID INT PRIMARY KEY,
   EmpName VARCHAR(50),
   DepartmentID INT
 );

 --Insert the values into Employees1 table 
 INSERT INTO Employees1 (EmpID, EmpName, DepartmentID) VALUES
   (1, 'Alice',   101),
   (2, 'Bob', 	102),
   (3, 'Charlie', 103),
   (4, 'Diana',   NULL),
   (5, 'Eve', 	101);


 -- Departments table
 CREATE TABLE Departments1 (
   DepartmentID INT PRIMARY KEY,
   DeptName VARCHAR(50),
   Location VARCHAR(50)
 );

 --Insert the values in Departments1
 INSERT INTO Departments1 (DepartmentID, DeptName, Location) VALUES
   (101, 'HR', 'New York'),
   (102, 'IT', 'San Francisco'),
   (103, 'Finance', 'Chicago'),
   (104, 'Sales','Boston');


SELECT * FROM Employees1
SELECT * FROM Departments1

--1. a) Inner Join: List all employees with assigned department names.
 SELECT E.EmpID, E.EmpName, D.DeptName
 FROM Employees1 E
 INNER JOIN Departments1 D
 � ON E.DepartmentID = D.DepartmentID; 

 --2.b) Left Join: Show all employees, with department name if assigned (NULL if not).
 SELECT E.EmpID, E.EmpName, D.DeptName
 FROM Employees1 E
 LEFT JOIN Departments1 D
   ON E.DepartmentID = D.DepartmentID;

--3.c) Right Join: Show all departments, with employee name if exists (NULL if none).
 SELECT D.DepartmentID, D.DeptName, E.EmpName
 FROM Employees1 E
 RIGHT JOIN Departments1 D
   ON E.DepartmentID = D.DepartmentID;

--4.d) Full Outer Join: Include all employees and departments, matching where possible.
 SELECT E.EmpID, E.EmpName, D.DeptName
 FROM Employees1 E
 FULL OUTER JOIN Departments1 D
   ON E.DepartmentID = D.DepartmentID;

--5.e) Cross Join: Generate every combination of employee names and department names.
 SELECT E.EmpName, D.DeptName
 FROM Employees1 E
 CROSS JOIN Departments1 D;

--6.f) Union All: 
--Create a list combining all employee names and department names in one column.
 SELECT EmpName AS Name FROM Employees1
 UNION ALL
 SELECT DeptName FROM Departments1;	

--7.g) Intersect: Find department IDs present in both tables.
 SELECT DepartmentID FROM Employees1
 INTERSECT
 SELECT DepartmentID FROM Departments1;

--8.h) Except: List department IDs in Departments but not in Employees.
 SELECT DepartmentID FROM Departments1
 EXCEPT
 SELECT DepartmentID FROM Employees1;
