--Assignment No. 08 


--Create a table named Products1
CREATE TABLE Products1 (
 � ProductID INT PRIMARY KEY,
 � ProductName VARCHAR(50),
 � Price DECIMAL(10,2),
 � QuantitySold INT,
 � Category VARCHAR(50)
 );

 --Insert the given values in Products1
  INSERT INTO Products1 (ProductID, ProductName, Price, QuantitySold, Category) VALUES
   (1, 'Laptop', 	800.00,  5,  'Electronics'),
   (2, 'Smartphone', 600.00, 10,  'Electronics'),
   (3, 'Desk Chair', 120.00, 15,  'Furniture'),
   (4, 'Table',  	200.00,  8,  'Furniture'),
   (5, 'Notebook', 	5.00, 20,  'Stationery'),
   (6, 'Pen',      	2.00, 50,  'Stationery');


--This will be inner query where it returns the avg price of products is 2
SELECT AVG(Price)Avg_Price FROM Products1;

--1. a) Above-Average Price: Select products whose Price exceeds the average price.
/*The query gives the insight that the productnames Laptop & Smartphone in electronics category 
having the exceed price than average price of products */

 SELECT * FROM Products1
 WHERE Price > (
 � SELECT AVG(Price) FROM Products1
 );

 --Below Average Price Products 
 --The products Desk chair ,Table,Notebook , Pen in Furniture and Stationary category products comes under the below avg price of product 
 SELECT * FROM Products1 
 WHERE Price < (
 SELECT AVG(Price) FROM Products1
 );


 --2.b) Most Expensive Product: Display the ProductName and Price of the highest-priced item.
 --The query will return the highest top most priced item productname as laptop having price 800
SELECT TOP 1 ProductName, Price
FROM Products1
ORDER BY Price DESC;

--Top 3 products having highest price => Laptop,smartphones ,Tables 
SELECT TOP 3 ProductName, Price
FROM Products1
ORDER BY Price DESC;

--The products having less price =>Pen,Notebook,Desk Chair
SELECT TOP 3 ProductName, Price
FROM Products1
ORDER BY Price ASC;



--3.c) Category Counts: Show the total number of products in each Category (using a subquery).

 SELECT DISTINCT Category,
   (SELECT COUNT(*)
    FROM Products1 P2
    WHERE P2.Category = P1.Category) AS ProductCount
 FROM Products1 P1;


 SELECT AVG(QuantitySold) FROM Products1;

--4.d) Below-Average Sales: Find products with QuantitySold below the average quantity sold.
--It gives the average  QuantitySold Products from Products1 Table 
 SELECT * FROM Products1
 WHERE QuantitySold < (
   SELECT AVG(QuantitySold) FROM Products1
 );

 --5.e) Electronics View: Create a view for all Electronics products.
 --This will create a view ElectronicsView where category of electronics from Products1 
 CREATE VIEW ElectronicsView AS
 SELECT * FROM Products1
 WHERE Category = 'Electronics';


 --It's shows a created  view  where category is Electronics 
 SELECT * FROM ElectronicsView;

 --This will drop the view named electronics
 DROP view ElectronicsView;


