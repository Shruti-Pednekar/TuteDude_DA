CREATE DATABASE Assignment10;

USE Assignment10;

 CREATE TABLE Employees (
   EmpID INT PRIMARY KEY,
   Name VARCHAR(50),
   Department VARCHAR(50),
   Email VARCHAR(50)
 );
 INSERT INTO Employees (EmpID, Name, Department, Email) VALUES
   (1, 'Alice Johnson','HR', 'alice.johnson@example.com'),
   (2, 'Bob Smith','IT', 'bob.smith@example.com'),
   (3, 'Charlie Brown','Finance','charlie.brown@example.com'),
   (4, 'Diana Prince','HR','diana.prince@example.com'),
   (5, 'Eve Adams','IT','eve.adams@example.org');

--1.a) @example.com Emails: List employees with emails in the example.com domain.
--This will helpful to check correct domain in email of employees it must be match with right criteria
 SELECT Name, Email FROM Employees WHERE Email LIKE '%@example.com';

 --2.b) Names Starting with 'A': Select employees whose names start with 'A'.
 --This will be helpful for finding the specific names staring with their names 1st letter 
 SELECT Name FROM Employees WHERE Name LIKE 'A%';


 --3.c) Names Ending with 'son': Find employees whose names end with 'son'.\
 --This will be useful to find the records where we know the details of last word or letters 
 SELECT Name FROM Employees WHERE Name LIKE '%son';


 --4.d) Second Letter 'v': Retrieve employees whose second character in the name is 'v'.
 --It's useful when it will not able to find out the specific name where shows the error .
 SELECT Name FROM Employees WHERE SUBSTRING(Name,2, 1) = 'v';


 --5.e) Departments Containing 'IT': Select employees in departments containing 'IT'.
 --This will helpful find any data contains the present letters 
 SELECT Name, Department FROM Employees WHERE Department LIKE '%IT%';


 --6.f) Case-Insensitive 'hr': Find employees in departments with 'hr' regardless of case.
 --Though the hr word in table in upper case the query will fetch the result with lower case also its not case sensitive 
 SELECT Name, Department FROM Employees WHERE LOWER(Department) LIKE '%hr%';


 SELECT * FROM Employees;