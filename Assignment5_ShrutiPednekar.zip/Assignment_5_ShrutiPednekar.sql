USE Assignments
-- Create table Products 
CREATE TABLE Products (
   ProductID INT PRIMARY KEY,
   ProductName VARCHAR(50),
   Category VARCHAR(50),
   Price DECIMAL(10,2),
   Stock INT
 );


 --Insert the values in Product Table 
  INSERT INTO Products (ProductID, ProductName, Category, Price, Stock) VALUES
   (1, 'Laptop',	'Electronics', 800.00,  50),
   (2, 'Smartphone','Electronics', 600.00,  30),
   (3, 'Desk Chair','Furniture',   120.00, 100),
   (4, 'Table', 	'Furniture',   200.00,  20),
   (5, 'Notebook',  'Stationery',	5.00, 500),
   (6, 'Pen',   	'Stationery',	2.00,1000);

 
 
SELECT * FROM Products


 /*a) Electronics & Furniture: Retrieve products in categories Electronics or Furniture.
 SQL Pattern: WHERE Category IN ('Electronics','Furniture')*/

 SELECT * FROM Products WHERE Category IN ('Electronics','Furniture');
 
/* b) Price Range: Find products with price between 100 and 800.
SQL Pattern: WHERE Price BETWEEN 100 AND 800 */
SELECT * FROM Products WHERE Price BETWEEN 100 AND 800;

/*3.c) Stock Range: List products whose stock is between 50 and 500.
 SQL Pattern: WHERE Stock BETWEEN 50 AND 500 */
 SELECT * FROM Products WHERE Stock BETWEEN 50 AND 500;

 /* 4.d) Name Contains 'Pen': Select products with 'Pen' anywhere in the name.
 SQL Pattern: WHERE ProductName LIKE '%Pen%' */
 SELECT * FROM Products WHERE ProductName LIKE '%PEN%';

 /* 5.e) Name Starts With 'S': Retrieve products whose names start with 'S'.
 SQL Pattern: WHERE ProductName LIKE 'S%' */
 SELECT * FROM Products WHERE ProductName LIKE 'S%';

 /* 6.f) Category & Price: Products in Stationery or Furniture and price 100�300.
 SQL Pattern: WHERE Category IN ('Stationery','Furniture') AND Price BETWEEN 100 AND 300 */
 SELECT * FROM Products WHERE Category IN ('Stationery','Furniture') AND Price BETWEEN 100 AND 300

/* 7.g) Low-Price 'o': Products priced 1�10 and name contains 'o'.
 SQL Pattern: WHERE Price BETWEEN 1 AND 10 AND ProductName LIKE '%o%' */
 SELECT * FROM Products WHERE Price BETWEEN 1 AND 10 AND ProductName LIKE '%o%';

