CREATE DATABASE Assignment9;
USE Assignment9;



--Create table Employees
CREATE TABLE Employees (
 � EmpID INT PRIMARY KEY,
 � Name VARCHAR(50),
 � DateOfBirth DATE,
 � JoinDate DATE
 );

-- Insert values in Employees table 
INSERT INTO Employees (EmpID, Name, DateOfBirth, JoinDate) VALUES
 � (1, 'Alice Johnson', '1985-05-20', '2010-06-15'),
 � (2, 'Bob Smith','1990-08-10', '2015-09-01'),
 � (3, 'Charlie Brown','1988-03-25', '2012-11-12'),
 � (4, 'Diana Prince',�'1992-01-30', '2017-07-08'),
 � (5, 'Eve Adams', '1987-12-05', '2013-03-20');

 SELECT * FROM Employees

 --1.a) Current Date & Time: Display the current system date and time.
-- This will help to know the current timestamp 
 SELECT CURRENT_TIMESTAMP as current_time_stamp;

-- 2.b) Calculate Age: Compute each employee�s age in years based on DateOfBirth.
/* 
SELECT Name, FLOOR(DATEDIFF(CURRENT_DATE, DateOfBirth)/365.25) AS Age FROM Employees;
The given query is not supported in Microsoft SQL management studio its showing that DATEDIFF() requires 3 argu.
showing error message after executing the query 
Msg 156, Level 15, State 1, Line 28
Incorrect syntax near the keyword 'CURRENT_DATE'.

*/
--so i am using given query to comes output as expected 
-- The datediff function is useful in company to know the customers working in company as per age group 
 SELECT Name, 
       FLOOR(DATEDIFF(day, DateOfBirth, GETDATE()) / 365.25) AS Age 
FROM Employees ORDER BY Age ASC ;


--3.c) Calculate Experience: Compute total years of service since JoinDate.
 /*
 SELECT Name, FLOOR(DATEDIFF(CURRENT_DATE, JoinDate)/365.25) AS YearsExperience FROM Employees;
 the query in assignment  gives an error that datediff() fun requires 3argu so use different query 
 */
 --This will helpful to manager that how much experience  the people have in the company also necessary for promotion purpose
 --It is useful to track the service of any employee in the company 
 --In this employee table Alice Johnson has 16 years experience whether the Diana Prince having 9 years experience +
 SELECT Name, DATEDIFF(YEAR, JoinDate, GETDATE()) AS YearsExperience FROM Employees ORDER BY YearsExperience DESC;


--4.d) Extract DOB Components: Extract year, month, and day from DateOfBirth.
--This will help to manager that check and extract the employees birth year,month,day from  there Birthdate cols 
 SELECT Name, YEAR(DateOfBirth) AS BirthYear, MONTH(DateOfBirth) AS BirthMonth, DAY(DateOfBirth) AS BirthDay FROM Employees;


 --5.e) Born in August: List employees born in the month of August.
 --The query gets helpful to know the month of the birth of any employee.
 --If the company celebrate the birthday of employees every month then this will be helpful.
 SELECT Name FROM Employees WHERE MONTH(DateOfBirth) = 8;


 --6.f) Upcoming Birthdays: Display names of employees whose birthdays fall in the next 30 days.
 /*The assignment q. query gives the error  
 SELECT Name FROM Employees WHERE
   DATE_FORMAT(DATE_ADD(DateOfBirth, INTERVAL YEAR(CURRENT_DATE)-YEAR(DateOfBirth) YEAR), '%m-%d')
   BETWEEN DATE_FORMAT(CURRENT_DATE, '%m-%d') AND DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY), '%m-%d');
*/
   SELECT Name
FROM Employees
WHERE 
    DATEADD(year, DATEDIFF(year, DateOfBirth, GETDATE()), DateOfBirth) 
    BETWEEN CAST(GETDATE() AS DATE) AND DATEADD(day, 30, CAST(GETDATE() AS DATE))
OR 
    DATEADD(year, DATEDIFF(year, DateOfBirth, GETDATE()) + 1, DateOfBirth) 
    BETWEEN CAST(GETDATE() AS DATE) AND DATEADD(day, 30, CAST(GETDATE() AS DATE));

SELECT * FROM Employees

INSERT INTO Employees VALUES 
(6,'Fekao Gemi','1986-07-15','2014-04-10');