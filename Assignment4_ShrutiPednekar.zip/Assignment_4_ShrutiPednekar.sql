--create database
CREATE DATABASE Assignments

USE Assignments

--create table 
CREATE TABLE Employees 
(EmpID INT PRIMARY KEY,
Name VARCHAR(50),
Department VARCHAR(30),
Salary DECIMAL(10,2))

--Insert values in table
INSERT INTO Employees (EmpID, Name, Department, Salary) VALUES
   (1, 'John Doe', 'HR', 50000),
   (2, 'Jane Smith', 'IT', 60000),
   (3, 'Alice Johnson', 'Finance', 55000),
   (4, 'Bob Brown', 'HR', 45000),
   (5, 'Charlie White', 'IT', 65000);

--create second table Department
CREATE TABLE Departments 
(DeptID INT PRIMARY KEY,
DeptName VARCHAR(50),
Location VARCHAR(50))

--insert the values in Departments table 
INSERT INTO Departments (DeptID, DeptName, Location)
VALUES 
(101, 'Sales', 'New York');


--a. Retrive all the records 
SELECT * FROM Employees

-- b. List distinct departments from the Employees table:

SELECT DISTINCT Department FROM Employees;

--c. Find employees with salary > 55000:

SELECT * FROM Employees WHERE Salary > 55000;